﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntities.Models
{
    public class tbl_refreshtoken
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [StringLength(100)]
        public string username { get; set; }
        [StringLength(100)]
        public string TokenId { get; set; }
        [StringLength(100)]
        public string RefreshToken { get; set; }
    }
}
