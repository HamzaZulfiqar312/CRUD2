﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataEntities.Models
{
    public class JWTSetting
    {
        public string SecretKey { get; set; }
    }//now going to register key in start-up class

}
