﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace DataEntities.Models
{
    public class Products
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int product_id { get; set; }
        public int category_id { get; set; }
        [StringLength(100)]
        public string product_name { get; set; }
        public int product_unit_price { get; set; }
        public int product_quantity { get; set; }
        [JsonIgnore]
        public Categories Categories { get; set; }
    }
}
