
create database CRUD

use CRUD


--update-database

--Add-Migration CRUDMigration -Project DataEntities--


create table categories
(category_id int primary key, category_name varchar(100))

-- Inserting dummy data into Categories Table
INSERT INTO Categories (category_id, category_name)
VALUES (1, 'Electronics'),
       (2, 'Clothing'),
       (3, 'Home');


create table products
(product_id int primary key, category_id int , 
product_name varchar(100), product_unit_price int,
product_quantity int
)

-- Inserting dummy data into Products Table
INSERT INTO Products (product_id,category_id, product_name, product_unit_price,product_quantity)
VALUES (1,1, 'Laptop', 1000, 1),
       (2,2, 'T-Shirt', 200, 2),
       (3,3, 'Sofa', 500, 13),
       (4,1, 'Tablet', 400, 10),
       (5,2, 'Dress', 50, 90),
       (6,3, 'Chair', 100, 40);




create table UsersCred(username varchar(50) primary key, pasword int, role varchar(50))

insert into UsersCred values
('HZ15', 12345,''),
('admin',12345,'admin')

create table tbl_refreshtoken(username varchar(100) primary key, TokenId varchar(100), RefreshToken varchar(100), )


insert into tbl_refreshtoken values
('HZ15', '123d','sfs34'),
('admin', '123d','sfs34')

select* from products

select* from categories
select* from UsersCred


select* from tbl_refreshtoken


drop database CRUD2