﻿using BusinessOperations.InterfacesClases;
using DataEntities.GenaricRepository;
using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.Services
{

    public class productsService : IProductsService
    {
        IRepository<Products> repo;

        public productsService()
        {

        }

        public productsService(IRepository<Products> repo)
        {
            this.repo = repo;
        }

        public Products GetProductById(int id)
        {
            return repo.GetByID(id);
        }

        public List<Products> GetProducts()
        {
            return repo.GetAll();
        }

        public void InsertProduct(Products product)
        {
            repo.Insert(product);
        }

        public void UpdateProduct(Products product)
        {
            repo.Update(product);
        }

        public void DeleteProduct(int id)
        {
            repo.Delete(id);
        }

    }
}
