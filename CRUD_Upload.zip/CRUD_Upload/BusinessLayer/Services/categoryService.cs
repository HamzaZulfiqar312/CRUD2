﻿using BusinessOperations.InterfacesClases;
using DataEntities.GenaricRepository;
using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.Services
{

    public class categoryService : ICategoryService
    {
        IRepository<Categories> repo;

        public categoryService()
        {

        }

        public categoryService(IRepository<Categories> repo)
        {
            this.repo = repo;
        }

        public Categories GetCategoryById(int id)
        {
            return repo.GetByID(id);
        }

        public List<Categories> GetCategories()
        {
            return repo.GetAll();
        }

        public void InsertCategory(Categories category)
        {
            repo.Insert(category);
        }

        public void UpdateCategory(Categories category)
        {
            repo.Update(category);
        }

        public void DeleteCategory(int id)
        {
            repo.Delete(id);
        }

    }
}
