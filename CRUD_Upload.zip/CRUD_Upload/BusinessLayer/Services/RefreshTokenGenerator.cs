﻿using BusinessOperations.InterfacesClases;
using DataEntities.GenaricRepository;
using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.Services
{
    public class RefreshTokenGenerator : IRefreshTokenGenerator
    {
        IRepository<tbl_refreshtoken> repo;
        public RefreshTokenGenerator( IRepository<tbl_refreshtoken> repo)
        {
            this.repo = repo;
        }


        public tbl_refreshtoken getByID(string id)
        {
            return this.repo.GetByStringID(id);
        }


        public string GenerateToken(string username)
        {
            var randomnumber = new byte[32];
            using (var randomnumbergenerator = RandomNumberGenerator.Create())
            {
                randomnumbergenerator.GetBytes(randomnumber);
                string RefreshToken = Convert.ToBase64String(randomnumber);

//              var _user = context.tbl_refreshtoken.FirstOrDefault(o => o.UserId == username);
                var _user = this.repo.GetByStringID(username);
                if (_user != null)
                {
                    _user.RefreshToken = RefreshToken;

                    this.repo.Update(_user);
//                    context.SaveChanges();
                }
                else
                {
                    tbl_refreshtoken tblRefreshtoken = new tbl_refreshtoken()
                    {
                        username = username,
                        TokenId = new Random().Next().ToString(),
                        RefreshToken = RefreshToken
                        // IsActive = true

                    };

                 //   insert_refresh(tblRefreshtoken);
                }

                return RefreshToken;
            }
        }

        //public void insert_refresh(tbl_refreshtoken tbl_refreshtoken)
        //{
        //   this.repo.Insert(tbl_refreshtoken);
        //}
    }
}
