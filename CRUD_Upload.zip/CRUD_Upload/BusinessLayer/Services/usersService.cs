﻿using BusinessOperations.InterfacesClases;
using DataEntities.GenaricRepository;
using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.Services
{
    public class usersService : IUsersService
    {
        IRepository<UsersCred> repo;
        public usersService()
        {
                
        }

        public usersService(IRepository<UsersCred> repo)
        {
            this.repo = repo;
        }

        public UsersCred getUserByID(string id)
        {
            return repo.GetByStringID(id);
        }

        public List<UsersCred> getUsers()
        {
            return repo.GetAll();
        }
    }
}
