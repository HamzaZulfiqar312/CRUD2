﻿using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.InterfacesClases
{
   public interface IRefreshTokenGenerator
    {
        string GenerateToken(string username);


        public tbl_refreshtoken getByID(string id);
        //public void insert_refresh(tbl_refreshtoken tbl_refreshtoken);

    }
}
