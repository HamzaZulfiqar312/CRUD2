﻿using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.InterfacesClases
{
    public interface IUsersService
    {
        public List<UsersCred> getUsers();
        public UsersCred getUserByID(string id);
    }
}
