﻿using DataEntities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessOperations.InterfacesClases
{
    public interface IProductsService
    {
        public List<Products> GetProducts();

        public Products GetProductById(int id);

        public void InsertProduct(Products product);

        public void UpdateProduct(Products product);

        public void DeleteProduct(int id);
    }
}
