﻿using BusinessOperations.InterfacesClases;
using DataEntities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        ICategoryService categoryService;

        public CategoriesController(ICategoryService categoryService)
        {
            this.categoryService = categoryService;
        }

        [Route("GetAllCategories")]
        [HttpGet]
        public List<Categories> Getcategorys()
        {
            return categoryService.GetCategories();
        }


        [Route("GetCategoryByID")]
        [HttpGet]
        public Categories GetCategoryByID(int id)
        {
            return categoryService.GetCategoryById(id);
        }

        [Route("Insertcategory")]
        [HttpPost]
        public void Insertcategory(Categories category)
        {
            categoryService.InsertCategory(category);
        }

        [Route("UpdateCategory")]
        [HttpPost]
        public void UpdateCategory(Categories category)
        {
            categoryService.UpdateCategory(category);
        }

        [Route("DeleteCategory")]
        [HttpPost]
        public void Deletecategory(int id)
        {
            categoryService.DeleteCategory(id);
        }


    }
}
