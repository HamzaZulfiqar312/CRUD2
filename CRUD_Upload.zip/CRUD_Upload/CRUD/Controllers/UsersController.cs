﻿using BusinessOperations.InterfacesClases;
using DataEntities;
using DataEntities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace CRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {

        IUsersService _iusersService;
        private readonly JWTSetting setting;
        private readonly IRefreshTokenGenerator tokenGenerator;
        private readonly DataBContext _DataBContext;
        public UsersController(DataBContext _DataBContext,IUsersService _iusersService, IOptions<JWTSetting> options, IRefreshTokenGenerator refreshTokenGenerator)
        {
            this._iusersService = _iusersService;
            setting = options.Value;
            tokenGenerator = refreshTokenGenerator;
            this._DataBContext = _DataBContext;
        }

        [Route("GetUsers")]
        [HttpGet]
        public List<UsersCred> getUsers()
        {
            return this._iusersService.getUsers();
        }

        [Route("GetByID")]
        [HttpPost]
        public UsersCred getUserByID(string id)
        {
            return this._iusersService.getUserByID(id);
        }


        [NonAction]
        public TokenResponse Authenticate(string username, Claim[] claims)
        {
            TokenResponse tokenResponse = new TokenResponse();

            var tokenkey = Encoding.UTF8.GetBytes(setting.SecretKey);

            var tokenhandler = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddMinutes(1),
                signingCredentials: new SigningCredentials(new SymmetricSecurityKey(tokenkey), SecurityAlgorithms.HmacSha256)
                );
            tokenResponse.JWTToken = new JwtSecurityTokenHandler().WriteToken(tokenhandler);

            tokenResponse.RefreshToken = tokenGenerator.GenerateToken(username);

            return tokenResponse;
        }

        [NonAction]
        public IActionResult login([FromBody] Login login)
        {
            var _user = _DataBContext.UsersCred.FirstOrDefault(o => o.username == login.username && o.pasword == login.pasword);

            return Ok(_user);
        }



            [Route("Authenticate")]
        [HttpPost]
        public IActionResult Authenticate([FromBody] Login login)
        {

            TokenResponse tokenResponse = new TokenResponse();

            //var _user = _learnDBContext.tbluser.FirstOrDefault(o => o.userid == _usercred.username && o.password == _usercred.password);
            var _user = _DataBContext.UsersCred.FirstOrDefault(o => o.username == login.username && o.pasword == login.pasword);

            //var _user = this._iusersService.getUserByID(_usercred.username);
            if (_user == null)
                return NotFound();

            //then generate token for successfull credentials
            var tokenhandler = new JwtSecurityTokenHandler();

            var tokenkey = Encoding.UTF8.GetBytes(setting.SecretKey);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new System.Security.Claims.ClaimsIdentity(
                new Claim[]
                {
                new Claim(ClaimTypes.Name,_user.username),
                new Claim(ClaimTypes.Role,_user.role),
                }
                ),
                Expires = DateTime.Now.AddMinutes(5),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(tokenkey), SecurityAlgorithms.HmacSha256)
            };

            var token = tokenhandler.CreateToken(tokenDescriptor);
            string finaltoken = tokenhandler.WriteToken(token);

            tokenResponse.JWTToken = finaltoken;
            tokenResponse.RefreshToken = tokenGenerator.GenerateToken(login.username);


            //            return Ok(finaltoken); replaced.................
            return Ok(tokenResponse);
        }



        [Route("Refresh")]
        [HttpPost]
        public IActionResult Refresh([FromBody] TokenResponse token)
        {

            var tokenhandler = new JwtSecurityTokenHandler();
            SecurityToken securityToken;
            var principal = tokenhandler.ValidateToken(token.JWTToken, new TokenValidationParameters
            {


                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(setting.SecretKey)),
                ValidateIssuer = false,
                ValidateAudience = false

            }, out securityToken);

            var _token = securityToken as JwtSecurityToken;

            if (_token != null && !_token.Header.Alg.Equals(SecurityAlgorithms.HmacSha256))
            {
                return Unauthorized();
            }

            var username = principal.Identity.Name;
                        var _reftable = _DataBContext.tbl_refreshtoken.FirstOrDefault(o => o.username == username && o.RefreshToken == token.RefreshToken);
           
            if (_reftable == null)
            {
                return Unauthorized();
            }

            TokenResponse _result = Authenticate(username, principal.Claims.ToArray());

            return Ok(_result);
            //            return Ok();
        }




    }
}
