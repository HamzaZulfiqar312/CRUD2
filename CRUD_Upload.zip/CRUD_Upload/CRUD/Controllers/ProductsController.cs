﻿using BusinessOperations.InterfacesClases;
using DataEntities.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD.Controllers
{
    [Authorize(Roles = "admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        IProductsService productsService;

        public ProductsController(IProductsService productsService)
        {
            this.productsService = productsService;
        }

        [Route("GetAllProducts")]
        [HttpGet]
        public List<Products> GetProducts()
        {
            return productsService.GetProducts();
        }


        [Route("GetProductByID")]
        [HttpGet]
        public Products GetProductByID(int id)
        {
            return productsService.GetProductById(id);
        }

        [Route("InsertProduct")]
        [HttpPost]
        public void InsertRole(Products product)
        {
            productsService.InsertProduct(product);
        }

        [Route("UpdateProduct")]
        [HttpPost]
        public void UpdateProduct(Products product)
        {
            productsService.UpdateProduct(product);
        }

        [Route("DeleteProduct")]
        [HttpPost]
        public void DeleteProduct(int id)
        {
            productsService.DeleteProduct(id);
        }


    }
}
