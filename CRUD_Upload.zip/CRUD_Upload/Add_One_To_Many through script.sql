-- Creating Categories Table
CREATE TABLE Categories (
    category_id INT NOT NULL PRIMARY KEY,
    category_name VARCHAR(200) NOT NULL
);

-- Inserting dummy data into Categories Table
INSERT INTO Categories (category_id, category_name)
VALUES (1, 'Electronics'),
       (2, 'Clothing'),
       (3, 'Home');

	   
	   select* from Categories
	   select* from Products




-- Creating Products Table
CREATE TABLE Products (
    product_id INT NOT NULL PRIMARY KEY,
	category_id INT NOT NULL,
    product_name VARCHAR(200) NOT NULL,
    product_unit_price int NOT NULL,
    product_quantity int NOT NULL
    CONSTRAINT fk_category_id FOREIGN KEY (category_id) REFERENCES Categories(category_id)
);



-- Inserting dummy data into Products Table
INSERT INTO Products (product_id,category_id, product_name, product_unit_price,product_quantity)
VALUES (1,1, 'Laptop', 1000, 1),
       (2,2, 'T-Shirt', 200, 2),
       (3,3, 'Sofa', 500, 13),
       (4,1, 'Tablet', 400, 10),
       (5,2, 'Dress', 50, 90),
       (6,3, 'Chair', 100, 40);




